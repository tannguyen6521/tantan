load('language_list.js');

var TRANSLATE_URL = "https://fanyi.baidu.com/ait/text/translate";
var HOME_URL = "https://fanyi.baidu.com/";
var UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";

function execute(text, from, to) {
    var srcLang = from ? (languageMap[from] || from) : detectLanguage(text);
    var dstLang = languageMap[to] || to;
    return translateContent(text, srcLang, dstLang, 0);
}

// from/to arrive already mapped to Baidu codes — never re-map inside the retry path,
// or the second attempt would look them up again and get undefined.
function translateContent(text, from, to, retryCount) {
    if (retryCount > 2) return Response.error("Baidu translate failed after 3 attempts");

    var token = getAcsToken(retryCount > 0);
    if (!token) return Response.error("Could not obtain Baidu Acs-Token");

    var body = JSON.stringify({
        needNewlineCombine: false,
        disableCache: false,
        isAi: false,
        sseStartTime: Date.now() - 1,
        query: text,
        from: from,
        to: to,
        corpusIds: [],
        needPhonetic: true,
        domain: "common"
    });

    var response = fetch(TRANSLATE_URL, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "Accept": "text/event-stream",
            "Acs-Token": token,
            "Cookie": String(localCookie.getCookie() || ""),
            "Referer": HOME_URL,
            "Origin": "https://fanyi.baidu.com",
            "User-Agent": UA
        },
        body: body
    });
    if (!response.ok) return translateContent(text, from, to, retryCount + 1);

    var parts = response.text().split("\n");
    var trans = "";
    var rejected = false;

    for (var i = 0; i < parts.length; i++) {
        var part = parts[i];
        if (part.indexOf("data") !== 0) continue;
        var braceAt = part.indexOf("{");
        if (braceAt < 0) continue;

        var obj = JSON.parse(part.substring(braceAt));
        // Baidu answers HTTP 200 with an in-body error (errno 995 "request is not
        // authorized", data:null) once the Acs-Token is stale — retryable, not fatal.
        var tranData = obj.data;
        if (!tranData) {
            if (obj.errno) rejected = true;
            continue;
        }
        if (tranData.event === "Translating" && tranData.list) {
            for (var j = 0; j < tranData.list.length; j++) {
                trans += tranData.list[j].dst + "\n";
            }
        }
    }

    trans = trans.trim();
    if (!trans) {
        if (rejected) {
            localStorage.removeItem("acs_token");
            return translateContent(text, from, to, retryCount + 1);
        }
        return Response.error("Baidu translate returned no text");
    }
    return Response.success(trans);
}

// The Acs-Token is produced by Baidu's own acs-2060.js inside the page and is not
// reachable as a global (it lives in a closure behind their request interceptor).
// So: load the page in a headless WebView, hook fetch + XHR, poke the home input so
// the page issues its own translate request, and capture the header it attaches.
// One captured token serves many subsequent plain-HTTP calls, so it is cached and
// only re-acquired when Baidu starts rejecting it.
function getAcsToken(forceRefresh) {
    if (!forceRefresh) {
        var cached = localStorage.getItem("acs_token");
        if (cached) return cached;
    }

    var browser = Engine.newBrowser();
    var token = "";
    try {
        browser.launch(HOME_URL, 15000);

        browser.callJs("(function(){window.__cap=[];" +
            "var o=XMLHttpRequest.prototype.setRequestHeader;" +
            "XMLHttpRequest.prototype.setRequestHeader=function(k,v){try{if(/acs/i.test(k))window.__cap.push(v);}catch(e){}return o.apply(this,arguments);};" +
            "var of=window.fetch;" +
            "window.fetch=function(u,opt){try{if(opt&&opt.headers){var h=opt.headers;" +
            "if(h.forEach){h.forEach(function(v,k){if(/acs/i.test(k))window.__cap.push(v);});}" +
            "else{for(var k in h){if(/acs/i.test(k))window.__cap.push(h[k]);}}}}catch(e){}" +
            "return of.apply(this,arguments);};return 1;})()", 8000);

        browser.callJs("(function(){var i=document.querySelector('[class*=homeInput]');" +
            "if(!i)return 0;try{i.focus();}catch(e){}" +
            "if('value' in i){i.value='\\u4f60\\u597d';}else{i.textContent='\\u4f60\\u597d';}" +
            "i.dispatchEvent(new Event('input',{bubbles:true}));" +
            "i.dispatchEvent(new Event('change',{bubbles:true}));" +
            "i.dispatchEvent(new KeyboardEvent('keydown',{key:'Enter',keyCode:13,bubbles:true}));" +
            "return 1;})()", 8000);

        sleep(4500);
        token = unwrapBridge(browser.callJs("(window.__cap&&window.__cap.length)?window.__cap[window.__cap.length-1]:''", 8000));
    } catch (e) {
        token = "";
    }
    try { browser.close(); } catch (e) {}

    if (token) localStorage.setItem("acs_token", token);
    return token;
}

// callJs returns the value wrapped in an HTML document — pull the body text back out.
function unwrapBridge(value) {
    var s = String(value || "");
    var m = s.match(/<body>([\s\S]*?)<\/body>/);
    return (m ? m[1] : s).trim();
}

function detectLanguage(text) {
    var sampleText = text.substring(0, Math.min(200, text.length));
    var response = fetch("https://fanyi.baidu.com/langdetect", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query: sampleText })
    });
    if (response.ok) {
        var j = response.json();
        if (j && j.lan) return j.lan;
    }
    return "";
}
