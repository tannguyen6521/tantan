load('config.js');
// detail.js (audio) — url is a site route /album|/playlist|/artist/{id}. All three
// map to an "album" (playlist) format: a cover + a track list served by toc.js.
function execute(url) {
    let route = parseRoute(url);
    if (!route) return Response.error("Bad url: " + url);

    if (route.type === "song") {
        let s = resolveSong(route.query);
        return Response.success({
            name: s ? s.title : route.name,
            author: s ? s.artist : "",
            cover: s ? s.cover : "",
            description: "",
            detail: "",
            url: url,
            type: "audio",
            format: "audio",
            ongoing: false,
            locale: "global",
            tags: [], genres: [], suggests: [], comments: []
        });
    }

    if (route.type === "chart") {
        let cc = route.id;
        return Response.success({
            name: "Top Songs · " + cc.toUpperCase(),
            author: "Apple Charts",
            cover: BASE_URL + "/brand/og.png",
            description: "Daily top chart for " + cc.toUpperCase(),
            detail: "",
            url: routeUrl("chart", cc),
            type: "audio",
            format: "album",
            ongoing: true,
            locale: "global",
            tags: [], genres: [], suggests: [], comments: []
        });
    }

    if (route.type === "radio") {
        let d = apiJson("/api/radio/" + route.id);
        let tracks = d && d.tracks;
        let cover = "";
        if (tracks && tracks.length > 0) cover = coverOf(tracks[0].album || {});
        return Response.success({
            name: route.name || "Radio",
            author: "Octave Radio",
            cover: cover,
            description: "",
            detail: (tracks ? tracks.length : "") + " tracks",
            url: url,
            type: "audio",
            format: "album",
            ongoing: true,
            locale: "global",
            tags: [], genres: [], suggests: [], comments: []
        });
    }

    if (route.type === "podcast") {
        let d = apiJson("/api/podcast/" + route.id);
        let p = d && d.podcast;
        return Response.success({
            name: p ? p.title : "Podcast",
            author: (p && p.author) || "Podcast",
            cover: (p && (p.picture || p.image)) || "",
            description: (p && p.description) || "",
            detail: "",
            url: url,
            type: "audio",
            format: "album",
            ongoing: true,
            locale: "global",
            tags: [], genres: [], suggests: [], comments: []
        });
    }

    if (route.type === "album") {
        let d = apiJson("/api/album/" + route.id);
        if (!d || !d.album) return Response.error("Album not found");
        let a = d.album;
        return Response.success({
            name: a.title,
            author: (a.artist && a.artist.name) || "",
            cover: coverOf(a),
            description: (a.label || "") + (a.releaseDate ? " · " + a.releaseDate : ""),
            detail: a.nbTracks ? (a.nbTracks + " tracks") : "",
            url: url,
            type: "audio",
            format: "album",
            ongoing: false,
            locale: "global",
            tags: [],
            genres: [],
            suggests: [],
            comments: []
        });
    }

    if (route.type === "playlist") {
        let d = apiJson("/api/playlist/" + route.id);
        if (!d || !d.playlist) return Response.error("Playlist not found");
        let p = d.playlist;
        return Response.success({
            name: p.title,
            author: p.user || "Octave",
            cover: coverOf(p),
            description: "",
            detail: (p.tracks ? p.tracks.length : "") + " tracks",
            url: url,
            type: "audio",
            format: "album",
            ongoing: false,
            locale: "global",
            tags: [], genres: [], suggests: [], comments: []
        });
    }

    // artist — present the artist's top tracks as an album.
    let d = apiJson("/api/artist/" + route.id);
    if (!d || !d.artist) return Response.error("Artist not found");
    let ar = d.artist;
    return Response.success({
        name: ar.name,
        author: ar.name,
        cover: coverOf(ar),
        description: ar.bio || d.bio || "",
        detail: (d.top ? d.top.length : "") + " top tracks",
        url: url,
        type: "audio",
        format: "album",
        ongoing: false,
        locale: "global",
        tags: [], genres: [], suggests: [], comments: []
    });
}
