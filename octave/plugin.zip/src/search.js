load('config.js');
// search.js — also the listing target for home.js tabs. A tab passes a category
// keyword like "chart:albums" or a curated query via `query`; a real search
// passes a keyword. Single page (the API returns no pagination cursor).
function execute(query, page) {
    query = query || "";

    // Home/genre tabs pass "curated:<q>" so the same script can list a themed query.
    if (query.indexOf("curated:") === 0) {
        query = query.substring("curated:".length);
    }

    let data = apiJson("/api/search?q=" + encodeURIComponent(query));
    if (!data) return Response.error("Search failed");

    let items = [];

    (data.albums || []).forEach(function (a) {
        items.push({
            name: a.title,
            cover: coverOf(a),
            link: routeUrl("album", a.id),
            description: (a.artist && a.artist.name) || "Album",
            tag: "Album"
        });
    });

    (data.artists || []).forEach(function (ar) {
        items.push({
            name: ar.name,
            cover: coverOf(ar),
            description: "Artist",
            tag: "Artist",
            // Open a browsable album/track list instead of the static detail page.
            action: { type: "list", script: "artist.js", input: ar.id, data: "" }
        });
    });

    // Tracks whose album isn't already listed — link to the album.
    (data.tracks || []).forEach(function (t) {
        let alb = t.album || {};
        items.push({
            name: t.title,
            cover: coverOf(alb),
            link: routeUrl("album", alb.id),
            description: (t.artist && t.artist.name) || "",
            tag: ""
        });
    });

    return Response.success(items, "");
}
