// home.js — tabs. Each `input` is passed to search.js as `query`. The "curated:"
// prefix tells search.js to treat it as a themed search query.
function execute() {
    return Response.success([
        { title: "Pop Hits", input: "curated:Pop Hits", script: "search.js" },
        { title: "Hip-Hop", input: "curated:Hip-Hop", script: "search.js" },
        { title: "Chill Lofi", input: "curated:Chill Lofi", script: "search.js" },
        { title: "Focus", input: "curated:Focus Instrumental", script: "search.js" },
        { title: "Workout", input: "curated:Workout", script: "search.js" },
        { title: "2010s Hits", input: "curated:2010s Hits", script: "search.js" }
    ]);
}
