load('config.js');
// track.js (audio: step 2) — chap.js already resolved `data` to a direct mp3
// stream url (the 320kbps /audio/320 endpoint or a Deezer preview cdn). Both are
// real media, so return native directly. The 320 endpoint is CORS-gated on the
// site Origin, so send the same headers apiHeaders() uses.
function execute(data) {
    if (!data) return Response.error("No audio url");
    return Response.success({
        type: "native",
        data: data,
        host: BASE_URL,
        mimeType: "audio/mpeg",
        headers: apiHeaders()
    });
}
